#!/usr/bin/env bash

# 1. BUILD SOURCE
sudo python3 setup.py build

# 2. INSTALL FROM BUILD FOLDER
sudo python3 setup.py install
