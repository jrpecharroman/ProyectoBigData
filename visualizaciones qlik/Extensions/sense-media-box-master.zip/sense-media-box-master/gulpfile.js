'use strict';
var gulp = require( 'gulp' );
var senseGo = require( 'sense-go' );

senseGo.init( gulp, function () {

} );
